const socket = io();
const bloodGroups = ["A+", "O-", "B+", "AB+"];
const donorTypes = ["Regular", "First-Time", "Occasional"];
const bloodRequests = [
  { name: "John", location: "City Hospital", group: "A+", health: "Major issue" },
  { name: "Jane", location: "Green Clinic", group: "O-", health: "Minor issue" }
];

document.addEventListener("DOMContentLoaded", () => {
  bloodGroups.forEach(bg => {
    const li = document.createElement("li");
    li.textContent = bg;
    document.getElementById("blood-groups").appendChild(li);
  });

  donorTypes.forEach(dt => {
    const li = document.createElement("li");
    li.textContent = dt;
    document.getElementById("donor-types").appendChild(li);
  });
});

function promptBloodGroup() {
  const bg = prompt("Enter Blood Group:");
  if (!bg) return;
  showRequests(bg);
  loadMap();  // simulated map loading
}

function showRequests(group) {
  const container = document.getElementById("request-list");
  container.innerHTML = "";
  const filtered = bloodRequests.filter(r => r.group === group);
  filtered.forEach(req => {
    const div = document.createElement("div");
    div.innerHTML = `
      <p><strong>${req.name}</strong> at ${req.location} needs ${req.group}</p>
      <button onclick="showPopup('${req.health}')">View Health Issue</button>`;
    container.appendChild(div);
  });
  document.getElementById("send-request-btn").style.display = "inline-block";
}

function showPopup(health) {
  document.getElementById("popup").style.display = "block";
  document.getElementById("health-issue-info").textContent = `Health Issue: ${health}`;
}
function closePopup() {
  document.getElementById("popup").style.display = "none";
}
let map;

function loadMapWithDonors(donors) {
  const mapContainer = document.getElementById("map-container");
  mapContainer.innerHTML = ""; // Clear previous map
  map = new google.maps.Map(mapContainer, {
    center: { lat: 28.6139, lng: 77.2090 }, // Default center (e.g. Delhi)
    zoom: 10,
  });

  donors.forEach(donor => {
    const marker = new google.maps.Marker({
      position: { lat: donor.lat, lng: donor.lng },
      map,
      title: donor.name,
    });
  });
}

async function fetchAndLoadMap() {
  const res = await fetch('/api/available-donors');
  const data = await res.json();
  loadMapWithDonors(data);
}

<script async
  src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&callback=fetchAndLoadMap">
</script>

function sendSocketRequest() {
  socket.emit("notifyDonors", { message: "Urgent blood donation request!" });
  alert("Request sent to all donors!");
}
